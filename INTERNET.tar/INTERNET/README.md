## 1 On 1 Security - INTERNET Repository

<img style="float: right;" src="images/logo.png" width="200" height="200">

1 On 1 Security provides secure website and application hosting tailored to meet the unique needs of individual clients.  As such we operate several stacks in Amazon Web Services consisting of a VPC and two Ubuntu 24.04.1 servers.  Primary buildout for this infrastructure lives in us-east-2-terraform currently deploying a custom AMI. 
The Packer directory ~~will be~~ is used for ~~future~~ iterations of deployment to build a custom gold image, both for AWS as well as our local Proxmox virtual environment.

Post-deployment management and configuration are stored in the Ansible directory along with playbooks; many used to reference scripts in the bash directory but Ansible internals have supplanted this mess.

Additional documentation is stored in the docs directory.

There are ~~a pair of~~ domains hosted via Docker; their compose.yaml configurations as well as html and/or backup data, if any, live in this directory.  Some of these dockers are operating Wordpress.

The firewall directory contains a LOCAL linux iptables firewall configuration, intended for use in conjunction with additional security controls such as Network Security Groups and/or ACLs.  Pulls data from abuseDB, fireHOL, and emerging threats to create block lists.  ~~It also queries Starlink for a list of Denver terminal IP addresses to flag as "friendly".  (Update to Dallas.)~~ [Replaced with terraform security group.]  This works in tandem with the firewall_analysis code in [1ON1SECURITY_APPS](https://gitlab.1on1.lan/1on1security_apps/1on1security_apps) repo.

Dependencies: ipset

The HellPot directory holds a binary copy of [HellPot](https://github.com/yunginnanet/HellPot) for Linux as well as a TOML configuration file. An additional "timeWasted.bash" script describes how to gauge useulness.  Additional documentation is needed to outline how nginx is configured.

### Directory structure

```
├── ansible
├── aws-us-west-1-terraform
├── bash
├── doc
├── docker
├── firewall
├── HellPot
├── logo.png
├── nginx
├── packer
├── README.md
├── staticPublicWeb
└── weblogAnalysis
```
