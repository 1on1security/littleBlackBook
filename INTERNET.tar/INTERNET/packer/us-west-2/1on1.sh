#!/bin/bash
set -x

# Install necessary dependencies
sudo apt-get update -y
sudo DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" dist-upgrade
sudo apt-get update
sudo apt-get -y -qq install curl wget git vim apt-transport-https ca-certificates

# Adding "1on1security" group and "ubuntu" user to it.
sudo groupadd -r 1on1security

# Installing SSH key for "ubuntu" and adding to sudo groups.
sudo mkdir -p /home/ubuntu/.ssh
sudo chmod 700 /home/ubuntu/.ssh
sudo cp /tmp/1on1security.aws.intern.pub /home/ubuntu/.ssh/authorized_keys
sudo chmod 600 /home/ubuntu/.ssh/authorized_keys
sudo chown -R ubuntu /home/ubuntu/.ssh
sudo usermod -aG 1on1security ubuntu
sudo usermod -aG sudo ubuntu

# Adding and "nefario" user.
sudo useradd -m -s /bin/bash -p '$1$ir7JbMU/$claOfA2vTcxdrHOKkJahz.' nefario

# Installing SSH key for "nefario" and adding to sudo groups.
sudo mkdir -p /home/ubuntu/.ssh
sudo chmod 700 /home/ubuntu/.ssh
sudo cp /tmp/1on1security.aws.intern.pub /home/ubuntu/.ssh/authorized_keys
sudo chmod 600 /home/ubuntu/.ssh/authorized_keys
sudo chown -R ubuntu /home/ubuntu/.ssh
sudo usermod -aG 1on1security nefario
sudo usermod -aG sudo nefario

# Backup /etc/sudoers and add oneonone group to allow no password use.
sudo cp /etc/sudoers /etc/sudoers.orig
echo "1on1security ALL=(ALL) NOPASSWD:ALL" | sudo tee -a /etc/sudoers
