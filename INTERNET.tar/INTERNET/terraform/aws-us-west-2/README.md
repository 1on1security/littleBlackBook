# aws-us-west-1-terraform
### terraform configuration

Deploys a custom VPC and EC2 hosts in us-west-1 region of AWS.
