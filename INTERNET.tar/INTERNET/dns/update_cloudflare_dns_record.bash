#!/bin/bash

source /home/julia/KEYS/cloudflare.api

domain=$1
record_name=$2
new_ip=$(/home/julia/code/prod/INTERNET/bash/aws-us-west-2-ip.bash)

# Get the Zone ID for the given domain
ZONE_ID=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones?name=$domain" \
  -H "X-Auth-Email: $EMAIL" \
  -H "X-Auth-Key: $API_KEY" \
  -H "Content-Type: application/json" | jq -r '.result[0].id')

# Check if the Zone ID was retrieved successfully
if [ -z "$ZONE_ID" ]; then
  echo "Failed to get Zone ID"
  exit 1
fi

# Get the Record ID for the given record name
RECORD_ID=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records?type=A&name=$record_name" \
  -H "X-Auth-Email: $EMAIL" \
  -H "X-Auth-Key: $API_KEY" \
  -H "Content-Type: application/json" | jq -r '.result[0].id')

# Check if the Record ID was retrieved successfully
if [ -z "$RECORD_ID" ]; then
  echo "Failed to get Record ID"
  exit 1
fi

# JSON payload
PAYLOAD=$(cat <<EOF
{
  "type": "A",
  "name": "$record_name",
  "content": "$new_ip",
  "ttl": 1200,
  "proxied": false
}
EOF
)

# Make the API call to update the A record
curl -s -X PUT "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records/$RECORD_ID" \
  -H "X-Auth-Email: $EMAIL" \
  -H "X-Auth-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD"
