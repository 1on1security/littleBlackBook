#!/bin/bash

source /home/julia/KEYS/cloudflare.api
ZONE_NAME=$1
# API endpoint
URL="https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records?type=A"

# Get the Zone ID for the given zone name
ZONE_ID=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones?name=$ZONE_NAME" \
  -H "X-Auth-Email: $EMAIL" \
  -H "X-Auth-Key: $API_KEY" \
  -H "Content-Type: application/json" | jq -r '.result[0].id')

# Check if the Zone ID was retrieved successfully
if [ -z "$ZONE_ID" ]; then
  echo "Failed to get Zone ID"
  exit 1
fi

# API endpoint to list A records
URL="https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records?type=A"

# Make the API call to list A records
curl -s -X GET "$URL" \
  -H "X-Auth-Email: $EMAIL" \
  -H "X-Auth-Key: $API_KEY" \
  -H "Content-Type: application/json" | jq '.result[]'
