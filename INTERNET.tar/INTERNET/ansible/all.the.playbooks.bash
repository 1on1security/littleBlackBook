#!/usr/bin/bash
ansible_root=/home/julia/code/prod/INTERNET/ansible
clear
echo
echo "HERE WE GO!"
echo "Hold on to your butts!"
echo
echo "System playbooks..."
ansible-playbook $ansible_root/system/play.system.install_base_packages.yaml
ansible-playbook $ansible_root/system/play.system.sshd_timeouts.yaml
ansible-playbook $ansible_root/system/play.system.install_system_updates.yaml
echo "Hosts will error out as they reboot..."
ansible-playbook $ansible_root/system/play.system.disable_ipv6.yaml
echo "Sleeping 45 seconds to allow reboot completion..."
sleep 15
echo 30...
sleep 15
echo 15...
sleep 15

clear
echo
echo "Hold on to your butts."
echo "Again!"
echo
echo "Nginx playbooks..."
ansible-playbook $ansible_root/nginx/play.nginx.install_nginx.yaml
echo "This one can _feel_ VERY slow... be patient, or disappointed."
ansible-playbook $ansible_root/nginx/play.nginx.copy_error_pages.yaml
ansible-playbook $ansible_root/nginx/play.nginx.copy_mercury_sites_available.yaml
ansible-playbook $ansible_root/nginx/play.nginx.copy_venus_sites_available.yaml
ansible-playbook $ansible_root/nginx/play.nginx.install_hellpot_snippets.yaml
/home/julia/code/prod/INTERNET/bash/venus-us-west-2.private-ip.bash > /home/julia/code/prod/INTERNET/dns/venus_privateip
ansible-playbook $ansible_root/nginx/play.nginx.update_play_variable.yaml
ansible-playbook $ansible_root/nginx/play.nginx.update_proxy_ip_addresses.yaml
ansible-playbook $ansible_root/nginx/play.nginx.install_certbot.yaml

echo "Apps playbooks..."
ansible-playbook $ansible_root/apps/play.apps.install_aws_cli.yaml
ansible-playbook $ansible_root/apps/play.apps.install_docker.yaml
ansible-playbook $ansible_root/apps/play.apps.install_firewall.yaml
ansible-playbook $ansible_root/apps/play.apps.install_packet_capture.yaml
ansible-playbook $ansible_root/apps/play.apps.install_hellpot.yaml

echo "Website/domain playbooks..."
echo "This one can feel very slow... be patient, or disappointed."

# push html and/or docker containers to venus
ansible-playbook $ansible_root/web/play.web.push.nullusspecialis.com.yaml

# create/update nginx sites-enabled symlinks on mercury
ansible-playbook $ansible_root/web/play.web.enable.nullusspecialis.com.yaml

# certbot certificate requests on mercury
ansible-playbook $ansible_root/nginx/play.nginx.certbot.nullusspecialis.com.yaml

# restart nginx post-config on mercury
ansible-playbook $ansible_root/nginx/play.nginx.restart.yaml

# start docker instances on venus
ansible-playbook $ansible_root/web/play.docker-compose-up.nullusspecialis.com.yaml
