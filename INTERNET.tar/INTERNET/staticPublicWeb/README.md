# staticPublicWeb

A collection of static web artifacts per domain.

deploy_static.bash provides a mechanism to sync contents of a subdirectory with the webroot of the virtual host on a live server in AWS.

Usage: deploy_static.bash domain

Example: ./deploy_static.bash 1on1security.com
