# BASH
### Scripts written in the Bourne Again SHell.

####There is a lot of "special sauce" up in here.
```
.
├── deploy-1on1-aws-us-east-2.bash
├── README.md
├── saturn_nginx_update.bash
├── teardown-1on1-aws-us-east-2.bash
└── update_instance_ids.bash
```

- deploy-1on1-aws-us-east-2.bash:
  - Invoke packer init and build in ../packer, logging to a file; that file is used to update terraform.auto.tfvars with ami value, which kicks off terraform apply in ../aws-us-east-2

- saturn_nginx_update.bash:
  - Obtains private ip address from saturn, replaces value of saturn_ip in ansible ngins proxy update playbook.

- shiva-1on1-aws-us-east-2.bash:
  - Invoke terraform destroy in ../aws-us-east-2, deregisters AMI, and deletes the snapshot.

- update_instance_ids.bash:
  - Performs the crucial task of updating ~/.ssh/config, ~/bin/jupiter-us-east-2.1on1.priv, ~/bin/saturn-us-east-2.1on1.priv, and /data/code/prod/INTERNET/ansible/_1on1.priv_inventory.yaml
