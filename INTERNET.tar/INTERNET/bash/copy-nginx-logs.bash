#!/bin/bash
# Extract logs from Docker instances to be included by logging agents.

# Define variables
CONTAINER_NAME="your_nginx_container_name"
LOCAL_DEST_DIR="/path/to/local/directory"

# Copy logs from Docker container to local directory
docker cp ${CONTAINER_NAME}:/var/log/nginx/. ${LOCAL_DEST_DIR}
