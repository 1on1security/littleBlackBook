#!/bin/bash
tfroot=/data/code/prod/INTERNET/terraform
# Fetch IP address ranges
ip_ranges=$(curl -sSL "https://geoip.starlinkisp.net/feed.csv" | grep Dallas | cut -d',' -f1 | head -n -4)

# Create a Terraform variable file
echo 'variable "starlink_ip_ranges" {' > $tfroot/aws-us-east-2/starlink_ips.tf
echo '  default = [' >> $tfroot/aws-us-east-2/starlink_ips.tf

# Add IP ranges to the variable file
for ip in $ip_ranges; do
  echo "    \"$ip/32\"," >> $tfroot/aws-us-east-2/starlink_ips.tf
done

echo '  ]' >> $tfroot/aws-us-east-2/starlink_ips.tf
echo '}' >> $tfroot/aws-us-east-2/starlink_ips.tf

echo "Terraform variable file created successfully!"
