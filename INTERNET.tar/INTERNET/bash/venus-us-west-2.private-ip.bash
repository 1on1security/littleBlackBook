#!/bin/bash
# ssh to venus and execute "ip a", then locally grep for inet 192 and format output.
venus-us-west-2.1on1.priv ip a | grep "inet 192"  | awk '{print $2}' | cut -d'/' -f1
