#!/bin/bash
root_dir=/home/julia/code/prod/INTERNET/terraform/aws-us-west-2
# change into east-2 directory and execute 'terraform show', then use grep/sed
# to whittle it down to just the public-ip address.
cd $root_dir && terraform show | grep public-ip | grep -oP '(?<=\=\s")[^"]+' | sed 's/"//g'
