#!/bin/bash
<< 'COMMENT'
This is "the glue". Begin by logging a fresh packer process to packer_output.log, capture the ami id, pass
ami id to terraform to deploy in VPC.  Update instance ID's in ~/.aws/config and scripts, update dns records
for live domains and source all.the.playbooks in ansible directory.
COMMENT

bash_root=/home/julia/code/prod/INTERNET/bash
packer_root=/home/julia/code/prod/INTERNET/packer/us-west-2
terraform_root=/home/julia/code/prod/INTERNET/terraform/aws-us-west-2
ansible_root=/home/julia/code/prod/INTERNET/ansible

# In packer directory initialize, format, and build image, set new_ami
echo "Starting packer..." && cd $packer_root
packer init . && packer fmt . && packer build image.pkr.hcl | tee packer_output.log
new_ami=$(grep us-west-2: packer_output.log | awk '{print $2}')

# In terraform directory update terraform.auto.tfvars with new_ami id.
echo "Terraform deploy stanza..." && cd $terraform_root
sed -i "/public_ami_image/c\public_ami_image = \"$new_ami\"" terraform.auto.tfvars
sed -i "/private_ami_image/c\private_ami_image = \"$new_ami\"" terraform.auto.tfvars
# apply/deploy new configuration
terraform init && terraform fmt && terraform validate && terraform apply -auto-approve

echo "Updating instance ids in scripts."
$bash_root/update_instance_ids.bash

#echo "Connecting to hosts to accept ssh keys..."
mercury-us-west-2.1on1.priv -o StrictHostKeyChecking=accept-new echo "success"
venus-us-west-2.1on1.priv -o StrictHostKeyChecking=accept-new echo "success"

# update appropriate DNS records.
echo "updating dns records for applicable domains..."
/home/julia/code/prod/INTERNET/dns/update_cloudflare_dns_record.bash nullusspecialis.com nullusspecialis.com

echo "Sourcing all.the.playbooks..." && cd $ansible_root
source $ansible_root/all.the.playbooks.bash
