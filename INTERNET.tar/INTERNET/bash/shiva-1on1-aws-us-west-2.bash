#!/bin/bash
<< 'COMMENT'
This will deliver complete and utter destruction upon our aws-us-west-2 deployment.
    śhrī-bhagavān uvācha
    kālo ’smi loka-kṣhaya-kṛit pravṛiddho
    lokān samāhartum iha pravṛittaḥ
    ṛite ’pi tvāṁ na bhaviṣhyanti sarve
    ye ’vasthitāḥ pratyanīkeṣhu yodhāḥ
Shiva the goddess of death is visting upon you - woe to you oh aws-us-west-2!
COMMENT

echo 'śhrī-bhagavān uvācha'
echo 'kālo ’smi loka-kṣhaya-kṛit pravṛiddho'
echo 'lokān samāhartum iha pravṛittaḥ'
echo 'ṛite ’pi tvāṁ na bhaviṣhyanti sarve'
echo 'ye ’vasthitāḥ pratyanīkeṣhu yodhāḥ'
echo
echo "This will deliver complete and utter destruction upon our aws-us-west-2 deployment."
echo "Shiva the goddess of death is visting upon you - woe to you oh aws-us-west-2!"

packer_root=/home/julia/code/prod/INTERNET/packer/us-east-2
terraform_root=/home/julia/code/prod/INTERNET/terraform/aws-us-west-2
ansible_inventory=/home/julia/code/prod/INTERNET/ansible/_1on1.priv_inventory.yaml

# In terraform directory perform a terraform destroy
echo "Terraform teardown..."
cd $terraform_root && terraform destroy

# lookup ami id for current image, deregister ami, and delete snapshot
current_image=$(aws ec2 describe-images --filters "Name=name,Values=1on1-packer-intern-gold" --query 'Images[*].ImageId' --output text)
echo "Current image: $current_image"
current_snapshot=$(aws ec2 describe-images --image-ids $current_image --query 'Images[*].BlockDeviceMappings[*].Ebs.SnapshotId' --output text)
echo "Current snapshot: $current_snapshot"
echo "Deregistering $current_image..."
aws ec2 deregister-image --image-id $current_image
echo "Deleting snapshot $current_snapshot..."
aws ec2 delete-snapshot --snapshot-id $current_snapshot
