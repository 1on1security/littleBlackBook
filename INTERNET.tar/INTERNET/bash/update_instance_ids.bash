#!/usr/bin/bash
tform_root=/home/julia/code/prod/INTERNET/terraform/aws-us-west-2
ansible_inventory=/home/julia/code/prod/INTERNET/ansible/_1on1.priv_inventory.yaml
echo "Updating instance-id in various files..."

# get/set new instance ids from terraform show
cd $tform_root
terraform show | tail -n 5 | grep mercury-instance-id | awk '{print $3}' | sed 's/\"//g' | tee new-mercury-instance
terraform show | tail -n 5 | grep venus-instance-id | awk '{print $3}' | sed 's/\"//g' | tee new-venus-instance
new_mercury_instance=$(cat $tform_root/new-mercury-instance)
new_venus_instance=$(cat $tform_root/new-venus-instance)

# update the ansible host for mercury and venus in ansible inventory
cp $ansible_inventory $ansible_inventory.bak
sed -i "/mercury/{n;s/ansible_host:.*/ansible_host: $new_mercury_instance/}" $ansible_inventory
sed -i "/venus/{n;s/ansible_host:.*/ansible_host: $new_venus_instance/}" $ansible_inventory

sed -i "/mercury/{n;n;n;s/--instance-id [^ ]*/--instance-id $new_mercury_instance\"\'/}" $ansible_inventory
sed -i "/venus/{n;n;n;s/--instance-id [^ ]*/--instance-id $new_venus_instance\"\'/}" $ansible_inventory

# update the instance ID for mercury and venus in ~/.ssh/config
cp ~/.ssh/config ~/.ssh/config.bak
sed -i "/mercury/{n;s/Host .*/Host $new_mercury_instance/}" ~/.ssh/config
sed -i "/venus/{n;s/Host .*/Host $new_venus_instance/}" ~/.ssh/config

# update the instance ID for mercury and venus in ~/bin/mercury-us-west-2.1on1.priv, venus.-us-west-2.1on1.priv
cp ~/bin/mercury-us-west-2.1on1.priv ~/bin/mercury-us-west-2.1on1.priv.bak
cp ~/bin/venus-us-west-2.1on1.priv ~/bin/venus-us-west-2.1on1.priv.bak
sed -i "/instance=/c\instance=\"$new_mercury_instance\"" ~/bin/mercury-us-west-2.1on1.priv
sed -i "/instance=/c\instance=\"$new_venus_instance\"" ~/bin/venus-us-west-2.1on1.priv
