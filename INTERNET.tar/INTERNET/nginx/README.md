# nginx configuration files

Nginx configuration files for two primary servers, earth-us-west-1 and mars-us-west-1 will be stored here, 
namely virtual host configurations and error messages.

Further automation of deployment will establish idempotence for DevOps.
