#!/bin/bash

# Variables
host=$(hostname -s)
log_path="/var/log/packetCapture"
interface="enX0"
s3_bucket=s3://1on1-pcap-$host
error_log="$log_path/error.log"
pid_file="$log_path/packet_capture.pid"
user="ubuntu"

# Ensure log_path directory exists and set ownership
mkdir -p "$log_path"
chown "$user":"$user" "$log_path"

# Define current file name using the current timestamp
current_file_name="$(date +%s).pcap"

# Function to log errors
log_error() {
    echo "$(date +'%Y-%m-%d %H:%M:%S') - $1" >> "$error_log"
    chown "$user":"$user" "$error_log"
}

# Function to start packet capture
start_capture() {
    /usr/bin/tcpdump -s0 -i "$interface" -w "$log_path/$current_file_name" &>/dev/null &
    echo $! > "$pid_file"
    chown "$user":"$user" "$pid_file"
    # Wait a few seconds to ensure the capture file is created
    sleep 5
    if [ -f "$log_path/$current_file_name" ]; then
        chown "$user":"$user" "$log_path/$current_file_name"
    else
        log_error "Capture file $current_file_name does not exist after waiting"
    fi
}

# Function to stop the previous packet capture gracefully
stop_previous_capture() {
    if [ -f "$pid_file" ]; then
        pid=$(cat "$pid_file")
        if ps -p "$pid" > /dev/null 2>&1; then
            kill -SIGTERM "$pid" || log_error "Failed to gracefully stop previous tcpdump process with PID $pid"
            # Wait for process to terminate
            sleep 5
            if ps -p "$pid" > /dev/null 2>&1; then
                kill -SIGKILL "$pid" || log_error "Failed to forcefully stop previous tcpdump process with PID $pid"
            fi
        fi
    fi
}

# Function to upload the most recent capture to S3 and delete it locally
upload_to_s3() {
    recent_file=$(ls -t "$log_path"/$host.* 2>/dev/null | head -n 1)
    if [ -n "$recent_file" ]; then
        if aws s3 cp "$recent_file" "$s3_bucket"; then
            rm -f "$recent_file" || log_error "Failed to delete $recent_file after upload"
        else
            log_error "Failed to upload $recent_file to S3"
        fi
    fi
}

# Function to rename the most recent capture file to jupiter.pcap.TIMESTAMP
rename_file() {
    recent_file=$(ls -t "$log_path"/*.pcap 2>/dev/null | head -n 1)
    if [ -n "$recent_file" ]; then
        timestamp=$(basename "$recent_file" .pcap)
        final_file="$log_path/$host.$timestamp"
        mv "$recent_file" "$final_file"
        chown "$user":"$user" "$final_file"
        echo "Renamed $recent_file to $final_file"
    fi
}

# Main execution
{
    stop_previous_capture
    upload_to_s3
    start_capture
    rename_file
} || {
    log_error "An error occurred during execution"
}
