# firewall

## a custom iptables firewall in bash

requirements: ipset

firewall.bash will create ipsets for several popular public block lists and populate them, then block and log for all of them.

The [firewall_analysis](https://gitlab.1on1.lan/1on1security_apps/1on1security_apps/-/tree/main/firewall_analysis) subdirectory of the 1ON1SECURITY_APPS repository is an internal application for analyzing the logs produced.