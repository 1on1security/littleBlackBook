#!/usr/bin/env bash
#
# update_abusedb_blacklist.bash dustin.decker@1on1security.com short and sweet, uses api key to fetch current
# blacklist from abusedb and saves it to abusedb.blocklist.txt for later read/reference by firewall.bash

abuse_key=04f57e1db11a4954308314bc7abf3b1a7e44b9c5a22cb4d932648976918752f8658429bf0bc191f3
curl -GSLs https://api.abuseipdb.com/api/v2/blacklist -d confidenceMinimum=90 -H "Key: $abuse_key" -H "Accept: text/plain" > /opt/firewall/abusedb.blocklist.txt
