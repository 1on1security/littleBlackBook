#!/usr/bin/env bash
#
# firewall.bash
# dustin.decker@1on1security.com

# This is a LOCAL linux iptables firewall configuration, intended for use in conjunction with additional
# security controls such as Network Security Groups and/or ACLs.

private_ip=$(ip a | grep 192 | grep -oP '(?<=inet )[^/]*')
webserver_ip=192.168.0.239
#public_ip=$(curl ipinfo.io | jq .ip | sed 's/"//g')

# RESET iptables
iptables -F # Flush all existing rules in the chains
iptables -X # delete all user-defined chains

# Create a "Tor" chain.
iptables -N tor
iptables -A tor -j LOG --log-prefix "Firewall Tor Dropped "
iptables -A tor -j DROP

# Create a "Emerging Threats" chain.
iptables -N emerging
iptables -A emerging -j LOG --log-prefix "Firewall ET Dropped "
iptables -A emerging -j DROP

# Create a "FireHOL" chain.
iptables -N fireHOL
iptables -A fireHOL -j LOG --log-prefix "Firewall FireHOL Dropped "
iptables -A fireHOL -j DROP

# Create a "abuseIPDB" chain.
iptables -N abuseIPDB
iptables -A abuseIPDB -j LOG --log-prefix "Firewall abuseIPDB Dropped "
iptables -A abuseIPDB -j DROP

# Create a "Catch All" chain.
iptables -N catch
iptables -A catch -j LOG --log-prefix "Firewall Catch Dropped "
iptables -A catch -j DROP

# Set the default policy for each chain to ACCEPT
iptables -P INPUT ACCEPT
iptables -P OUTPUT ACCEPT
iptables -P FORWARD ACCEPT

# destroy ipsets for threats if present.
ipset destroy tor > /dev/null 2>&1
ipset destroy emerging > /dev/null 2>&1
ipset destroy fireHOL > /dev/null 2>&1
ipset destroy abuseIPDB > /dev/null 2>&1

# create ipsets for threats.
ipset create tor hash:net hashsize 4096
ipset create emerging hash:net hashsize 4096
ipset create fireHOL hash:net hashsize 4096
ipset create abuseIPDB hash:net hashsize 4096

# fetch tor exit node list into tor ipset.
curl -sSL "https://check.torproject.org/torbulkexitlist" | sed '/^#/d' | while read IP; do
        ipset -q -A tor $IP
done

# fetch emerging-threats list into emerging ipset.
curl -sSL "https://rules.emergingthreats.net/fwrules/emerging-Block-IPs.txt" |  sed '/^#/d' | while read IP; do
        ipset -q -A emerging $IP
done

# fetch fireHOL list into fireHOL ipset.
curl -sSL "https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/firehol_level1.netset" | sed '/^#/d' | \
 sed '/192.168.0.0\/16/d' | sed '/127.0.0.0\/8/d' | while read IP; do
        ipset -q -A fireHOL $IP
done

# fetch abuseipdb blacklist into abuseIPDB - we are reading in from a file that is fetched less frequently than
# 24 hours to avoid hitting out limits.
cat /opt/firewall/abusedb.blocklist.txt | while read IP; do
        ipset -q -A abuseIPDB $IP
done

# DROP any inbound connection from threat lists.
iptables -A INPUT -m set --match-set tor src -j tor
iptables -A INPUT -m set --match-set emerging src -j emerging
iptables -A INPUT -m set --match-set fireHOL src -j fireHOL
iptables -A INPUT -m set --match-set abuseIPDB src -j abuseIPDB

# Allow established connections
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Allow outbound DNS traffic
iptables -A OUTPUT -p udp --dport 53 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -p tcp --dport 53 -m state --state NEW,ESTABLISHED -j ACCEPT

# Allow return DNS traffic
iptables -A INPUT -p udp --sport 53 -m state --state ESTABLISHED -j ACCEPT
iptables -A INPUT -p tcp --sport 53 -m state --state ESTABLISHED -j ACCEPT

# Allow inbound ssh from everywhere
iptables -A INPUT -p tcp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -p tcp --sport 22 -m state --state ESTABLISHED -j ACCEPT

# Allow inbound web ports from everywhere
iptables -A INPUT -p tcp -m multiport --dports 80,443 -j ACCEPT

# Allow outbound 80,443
iptables -A OUTPUT -p tcp -m multiport --dports 80,443 -j ACCEPT

# Allow Hell-Pot
iptables -A INPUT -p tcp --dport 666 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -p tcp --sport 666 -m state --state ESTABLISHED -j ACCEPT

# Allow traffic between $private_ip and $webserver_ip for TCP ports 80-90
iptables -A INPUT -p tcp --dport 80:90 -s $private_ip -d $webserver_ip -j ACCEPT
iptables -A OUTPUT -p tcp --sport 80:90 -d $private_ip -s $webserver_ip -j ACCEPT

# DROP any packet not explicitly allowed by earlier rules.
iptables -A INPUT -j catch
