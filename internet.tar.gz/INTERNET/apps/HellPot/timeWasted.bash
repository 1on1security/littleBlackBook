#!/usr/bin/env bash


totalSeconds=$(for X in /data/logs/earth-us-west-1/HellPot/HellPot*.log; do grep "DURATION" $X ;done | \
sed 's/\"//g' - | cut -d ',' -f 6 | grep DURATION | cut -d ':' -f 2 | paste -sd+ - | bc)/1

seconds=$(echo "scale=0 ; $totalSeconds" | bc)
minutes=$(echo "scale=0 ; $totalSeconds / 60" | bc)
hours=$(echo "scale=0 ; ($totalSeconds / 60) /60" | bc)
days=$(echo "scale=0 ; ($totalSeconds / 86400)" | bc)
weeks=$(echo "scale=0; ($totalSeconds / 604800)" | bc)
months=$(echo "scale=0; ($totalSeconds / 2678400)" | bc)

echo "Total Bot Time Wasted:"
echo
echo "Seconds: $seconds"
echo "Minutes: $minutes"
echo "Hours: $hours"
echo "Days: $days"
echo "Weeks: $weeks"
echo "Months (@30 days): $months"
echo
