# HellPot
[hellpot](https://github.com/yunginnanet/HellPot)

This repo holds a binary copy of HellPot for Linux as well as a TOML configuration file<p>
An additional "timeWasted.bash" script describes how to gauge useulness.
