#!/bin/bash
# change into east-1 directory and execute 'terraform show', then use grep/sed
# to whittle it down to just the public-ip address.
cd $terraform_root && terraform show | grep mars-public-ip | grep -oP '(?<=\=\s")[^"]+' | sed 's/"//g'
