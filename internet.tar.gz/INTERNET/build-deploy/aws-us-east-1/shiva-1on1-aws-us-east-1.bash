#!/bin/bash
echo "    śhrī-bhagavān uvācha"
echo "    kālo ’smi loka-kṣhaya-kṛit pravṛiddho"
echo "    lokān samāhartum iha pravṛittaḥ"
echo "    ṛite ’pi tvāṁ na bhaviṣhyanti sarve"
echo "    ye ’vasthitāḥ pratyanīkeṣhu yodhāḥ"
echo
echo "Shiva the goddess of death is visting upon you - woe to you oh aws-us-east-1!"
echo "This will deliver complete and utter destruction upon our aws-us-east-1 deployment."

source /data/code/prod/INTERNET/build-deploy/aws-us-east-1/VARS-us-east-1

# In terraform directory perform a terraform destroy
echo "Terraform teardown..."
cd $terraform_root && terraform destroy

# lookup ami id for current image, deregister ami, and delete snapshot
current_image=$(aws ec2 describe-images --region us-east-1 --filters "Name=name,Values=1on1-us-east-1-gold*" --query 'Images[*].ImageId' --output text)
echo "Current image: $current_image"
current_snapshot=$(aws ec2 describe-images --region us-east-1 --image-ids $current_image --query 'Images[*].BlockDeviceMappings[*].Ebs.SnapshotId' --output text)
echo "Current snapshot: $current_snapshot"
echo "Deregistering $current_image..."
aws ec2 deregister-image --region us-east-1 --image-id $current_image
echo "Deleting snapshot $current_snapshot..."
aws ec2 delete-snapshot --region us-east-1 --snapshot-id $current_snapshot
