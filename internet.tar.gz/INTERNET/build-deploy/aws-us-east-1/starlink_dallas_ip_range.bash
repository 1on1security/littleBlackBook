#!/bin/bash
source /data/code/prod/INTERNET/build-deploy/aws-us-east-2/VARS-us-east-2

# Fetch IP address ranges
ip_ranges=$(curl -sSL "https://geoip.starlinkisp.net/feed.csv" | grep Dallas | cut -d',' -f1 | head -n -4)

# Create a Terraform variable file
echo 'variable "starlink_ip_ranges" {' > $terraform_root/aws-us-east-1/starlink_ips.tf
echo '  default = [' >> $terraform_root/aws-us-east-1/starlink_ips.tf

# Add IP ranges to the variable file
for ip in $ip_ranges; do
  echo "    \"$ip/32\"," >> $terraform_root/aws-us-east-1/starlink_ips.tf
done

echo '  ]' >> $terraform_root/aws-us-east-1/starlink_ips.tf
echo '}' >> $terraform_root/aws-us-east-1/starlink_ips.tf

echo "Terraform variable file created successfully!"
