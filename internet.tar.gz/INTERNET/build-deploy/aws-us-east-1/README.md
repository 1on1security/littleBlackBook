# BASH
### Scripts written in the Bourne Again SHell.

#### There is a lot of "special sauce" up in here.

```
├── aws-us-east-1-ip.bash
├── deploy-1on1-aws-us-east-1.bash
├── README.md
├── shiva-1on1-aws-us-east-1.bash
├── starlink_dallas_ip_range.bash
└── VARS-us-east-1
```

- deploy-1on1-aws-us-east-1.bash:
  - Invoke packer init and build in ../packer, logging to a file; that file is used to update terraform.auto.tfvars with ami value, which kicks off terraform apply in ../aws-us-east-1

- aws-us-east-1-ip.bash:
  - Fetches private ip for jupiter from terraforum output, replaces value of jupiter_ip in ansible nginx proxy update playbook.

- shiva-1on1-aws-us-east-1.bash:
  - Invoke terraform destroy in ../aws-us-east-1, deregisters AMI, and deletes the snapshot.

- starlink_dallas_ip_range.bash:
  - Fetches and formats a list of public ip addresses for Starlink in Dallas, and adds them to a custom terraform file for use when deploying.  (It essentially says "allow ssh from here", and we'll need to add an IP range for Julia.)

- VARS-us-east-1:
  - A small but VERY important list of variables for this region.
