#!/bin/bash
# This is "the glue".  Build a packer image, update terraform.auto.tfvars to use the new AMI.
# Terraform apply to us-east-2, capture instance IDs and update local inventory/config files.

source /data/code/prod/INTERNET/build-deploy/aws-us-east-2/VARS-us-east-2
# In packer directory initialize, format, and build image, set new_ami
echo "Starting packer..." && cd $packer_root
packer init . && packer fmt . && packer build image.pkr.hcl | tee $log_root/packer_output.log
new_ami=$(grep us-east-2: $log_root/packer_output.log | awk '{print $2}')

# In terraform directory update terraform.auto.tfvars with new_ami id.
echo "Terraform deploy stanza..." && cd $terraform_root
sed -i "/public_ami_image/c\public_ami_image = \"$new_ami\"" terraform.auto.tfvars
sed -i "/private_ami_image/c\private_ami_image = \"$new_ami\"" terraform.auto.tfvars

# apply/deploy new configuration to aws
terraform init && terraform fmt && terraform validate && terraform apply -auto-approve | tee $log_root/terraform_output.log
new_earth_instance=$(tail -n 20 $log_root/terraform_output.log | grep earth-instance-id | awk '{print $3}' | sed 's/\"//g')
new_mars_instance=$(tail -n 20 $log_root/terraform_output.log | grep earth-instance-id | awk '{print $3}' | sed 's/\"//g')
tail -n 20 $log_root/terraform_output.log | grep mars-private-ip | awk '{print $3}' | sed 's/\"//g' > \
 /data/code/prod/INTERNET/build-deploy/temp_files/mars-private-ip
echo

echo "Updating firewall scripts..."
private_ip=$(cat /data/code/prod/INTERNET/build-deploy/temp_files/mars-private-ip)
sed -i "s/webserver_ip=[0-9\.]*/webserver_ip=$private_ip/" /data/code/prod/INTERNET/apps/firewall/firewall.bash
echo

echo "Updating ansible inventory with new instance IDs..."
sed -i "/earth/{n;s/ansible_host:.*/ansible_host: $new_earth_instance/}" $ansible_inventory
sed -i "/earth/{n;n;n;s/--instance-id [^ ]*/--instance-id $new_earth_instance\"\'/}" $ansible_inventory
sed -i "/mars/{n;s/ansible_host:.*/ansible_host: $new_mars_instance/}" $ansible_inventory
sed -i "/mars/{n;n;n;s/--instance-id [^ ]*/--instance-id $new_mars_instance\"\'/}" $ansible_inventory

# Update HostName for each host entry in SSH config
echo "Update HostName for each host entry in SSH config..."
ssh_config="$HOME/.ssh/config"
sed -i.bak \
    -e "/^Host earth-us-east-2.1on1.priv$/,/^  HostName/s/^  HostName .*/  HostName $new_earth_instance/" \
    -e "/^Host mars-us-east-2.1on1.priv$/,/^  HostName/s/^  HostName .*/  HostName $new_mars_instance/" \
    "$ssh_config"
