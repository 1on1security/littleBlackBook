# aws-us-east-2-terraform
### terraform configuration

Deploys a custom VPC and EC2 hosts in us-east-2 region of AWS.

Deploys hosts based on custom Packer [image build](../packer/us-east-2/) for the region.
