# packer
#### contains configuration to buid '1on1-packer-gold-${local.timestamp}' AMI in region identified by subdirectory name.
Build a new image - within subdir:
```
cd images
packer init image.pkr.hcl
packer build image.pkr.hcl
```
Based loosely on [Provisioning](https://developer.hashicorp.com/terraform/tutorials/provision/packer) tutorial.
