# us-east-2
#### configuration to buid '1on1-packer-gold-${local.timestamp}' AMI in us-east-2 

- image.pkr.hcl:
    - /home/nefario/KEYS/1on1security.aws.primary.pub into image /tmp directory

- 1on1.sh
    - updates ubuntu and adds local "nefario" user with a preencrypted password.
    - [Gnerated via:]<br>
```openssl passwd -1 "your_password_here"```

#####Initialize and format the local directory, then build the image.
```
packer init . && packer fmt . && packer build image.pkr.hcl
```
Output will include the AMI to support [aws-us-east-2-terraform](../../aws-us-east-2-terraform/) deployments, declared in terraform.auto.tfvars.