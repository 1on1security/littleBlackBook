## 1 On 1 Security - Julia Vvedenskaya Internship
### Welcome Julia!

I fully reworked my directory structure to follow higher-level purposes "first" so instead of an individual repository for every AWS region, there's simply one large repo.  I'm throwing you into the deep end of the pool by assigning responsibility for the US-EAST-1 region.  

**A word of WARNING up front: US-EAST-1 and US-EAST-2 look a LOT alike, and it's very easy to find yourself in the improper directory, which can damage live hosts.**  (I've actually removed the us-east-2 folder to avoid mishaps.)
A successful completion of this devops internship will result in the website polypussecuritatis.com being  deployed and accessible publicly from your region.

During this deployment you will familiarize yourself with:

- Building a Virtual Private Cloud (VPC) in AWS.
- Deploying a public and private Linux server instance.
- Configuring networking, applications and security for the servers.
- Deploy custom web code to the private server.

You'll be exposed to technologies such as Packer, Terraform and Ansible.

Walking through the execution of the primary deployment script will give you a feel for the overall "flow" of this style of deployment.  The 10K foot view:

1. Verify your Terraform configuration; specifically, region, AMI ID, host names.
2. Apply Terraform configuration, which deploys it into the us-east-1 region.
3. Utilizing Ansible playbooks manage system and application configurations resulting in the final deployment.
4. Make applicable DNS record changes.
5. Launch web content.
