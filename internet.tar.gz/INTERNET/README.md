## 1 On 1 Security - INTERNET Repository

<img src="docs/logo.png" width="300" height="300" />

![US Map](docs/us-aws-regions.png)


#### 1 On 1 Security provides secure website and application hosting tailored to meet the unique needs of individual clients.  As such we operate several stacks in Amazon Web Services consisting of a VPC and two Ubuntu 24.04.1 servers.  Primary buildout for this infrastructure lives in us-east-2-terraform currently deploying a custom AMI. 

```
.
├── apps
│   ├── aws-cli
│   ├── docker-compose-plugin
│   ├── firewall
│   ├── HellPot
│   └── packetCapture
├── build-deploy
│   ├── aws-us-east-1
│   ├── aws-us-east-2
│   ├── aws-us-west-1
│   ├── aws-us-west-2
│   ├── packer
│   ├── README.md
│   ├── temp_files
│   └── terraform
├── config-mgmt
│   ├── ansible
│   ├── dns
│   ├── iam_policies
│   ├── nginx
│   └── scripts
├── docs
├── logging
├── README.md
```
#### We're reciting our ABC's
- ***A*pps:** contains applications and related artifacts for deployment
- ***B*uild-deploy:** stage-one elementals including Packer build, Terraform
- ***C*onfig-mgt:** state-two configuration management
- ***D*ocs:** documentation and related data
- *logging:* output of build-deploy and config-mgt activities
- *web:* contains source dockerfiles and user data for hosted domains

#### A simplistic overview, we utilize four stages
1. We **build**-deploy
2. We **config**-mgmt
3. We **deploy** apps
4. We **export** web content
5. We **log and monitor**
6. Lather, Rinse, Repeat

The ***b*uild**-deploy stage is kicked off in the root of this repo: ```/data/code/prod/INTERNET``` by moving into the build directory of the destination region - in this example aws-us-east-2: ``` cd build-deploy/aws-us-east-2/```.

This is followed by sourcing our variables file: ```source build-deploy/aws-us-east-2/VARS-us-east-2```.

The real glue is presented in *deploy-1on1-aws-us-east-2.bash*. This initiates a build of our custom AMI image with Packer, which publishes the AMI in the us-east-2 region.  We further this build by passing the id of the new AMI to Terraform which deploys the image in a VPC within AWS.  (We can then copy the AMI from the us-east-2 region to other regions via the AWS console.)

```time ./deploy-1on1-aws-us-east-2.bash | tee $log_root/deploy.log```

This is quickly followed with the ***c*onfig-mgmt stage**, which utilizes Ansible playbooks to build out additional system configurations and settings to bring the hosts within our policy compliance needs.

```cd $ansible_root```<br>
```source aws-us-east-2```

While the config-mgmt stage is largely about compliance, the ***d*eploy apps stage** will piggyback on the same Ansible achain to deploy our custom applications such as firewall and packetCapture to the hosts.

The ***e*xport web content stage** involves customer web content. At present this is a 100% Docker-based deployment utilizing one of two official dockerfiles; nginx or wordpress.  These processes, too, are Ansible playbooks that can be chained in _aws-us-east-2_ or deployed manually.

### Ansible
In the _**config-mgmt/ansible**_ directory you'll find a structure similar to below.  Our inventory is defined in __1on1.priv_inventory.yaml_ while _ansible.cfg_ holds our overall configuration, defining SSH keys and other admistrivia.

```
.
├── _1on1.priv_inventory.yaml
├── ansible.cfg
├── apps
│   ├── play.apps.install_aws_cli.yaml
│   ├── play.apps.install_docker.yaml
│   ├── play.apps.install_firewall.yaml
│   ├── play.apps.install_hellpot.yaml
│   └── play.apps.install_packet_capture.yaml
├── certbot
│   ├── play.nginx.certbot.1on1security.com.yaml
├── nginx
│   ├── play.nginx.copy_error_pages.yaml
│   ├── play.nginx.copy_mercury_sites-available.yaml
│   ├── play.nginx.install_blocklist.yaml
│   ├── play.nginx.install_certbot.yaml
│   ├── play.nginx.install_hellbot_snippets.yaml
│   ├── play.nginx.install_nginx.yaml
│   ├── play.nginx.restart.yaml
│   ├── play.nginx.update_play_variable.yaml
│   └── play.nginx.update_proxy_ip_addresses.yaml
├── perms
│   └── play.system.docker_group_membership.yaml
├── README.md
├── system
│   ├── play.system.disable_ipv6.yaml
│   ├── play.system.hostname.mercury.yaml
│   ├── play.system.hostname.venus.yaml
│   ├── play.system.install_base_packages.yaml
│   ├── play.system.install_system_updates.yaml
│   └── play.system.sshd_settings.yaml
└── web
    ├── play.docker-compose-up.1on1security.com.yaml
    ├── play.web.enable.1on1security.com.yaml
    └── play.web.push.1on1security.com.yaml
```

![build flow document](docs/us-east-2-build-flow.png)