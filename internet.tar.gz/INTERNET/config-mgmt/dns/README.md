# dns
Using cloudflare API to update dns A records for hosted domains.

### API KEY:<br>
source /home/nefario/KEYS/cloudflare.api

### Usage:
```
update_cloudflare_dns.bash [domain]
```
makes calls to the get_cloudflare_a_records.bash script in this directory to set NEW_IP, the results of which come from terraform.

```
NEW_IP=$(/data/code/prod/INTERNET/dns/aws-us-west-1-ip.bash)
```