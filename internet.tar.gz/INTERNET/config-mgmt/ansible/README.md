# ansible

#### This repo holds 1on1security.com Ansible playbooks and configurations.
The ansible.cfg file has our ssh key, user and inventory file declared.<p>
Thus:<br> 
```ansible-playbook -i _1on1.priv_inventory.yaml play.nginx.yaml```<br>
and<br>
```ansible-playbook play.nginx.yaml```<br>
are functionally equivalent 

### Crib Notes on Ansible

List inventory from inventory.yaml file

```
ansible-inventory -i _1on1.priv_inventory.yaml --list
```

Test ansible connectivity and access with a ping
```
ansible _1on1 -m ping -i _1on1.priv_inventory.yaml
```

Execute declared ansible playbook against hosts in the inventory.yaml
```
ansible-playbook -i _1on1.priv_inventory.yaml "playbook.yaml"
ansible-playbook -i _1on1.priv_inventory.yaml "playbook.yaml" --check same, but a dry run.
```
