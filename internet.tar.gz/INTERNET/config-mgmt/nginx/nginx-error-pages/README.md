## Installation

Copy entire folder to /var/www/nginx-error-pages/

```
ln -s /var/www/nginx-error-pages/error_pages.conf /etc/nginx/snippets/error_pages.conf
ln -s /var/www/nginx-error-pages/error_pages_content.conf /etc/nginx/snippets/error_pages_content.conf
```


```
Then add to each of your vhosts the following:
```
include snippets/error_pages.conf;
```
